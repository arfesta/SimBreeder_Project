#' Create Cross Design
#'
#' This function allows you to create a crossdesign to use to make crosses
#' @param map genetic map created
#' @keywords extract genos from make crosses
#' @export
#' @examples
#' create.cross.design()


####Create Cross Design & Pedigree's####
create.cross.design <- function(mapinfo=map,parentinfo=parents, prog.percross=num.prog.percross, self.pars=pars,
                              cross.file.input=crossfileinput, gen=1, saveped=F,selftest=SELFTEST,
                              crossfile=CrossFile1, RandomMating=random.mating , SelfPar = self.par,
                              SP.MateSelect=sp.mateselect, MP.MateSelect=mp.mateselect,ancest.thresh=coancest.thresh,
                              AssortiveMating=assortive.mating, OPparphenos=s.12,reduced=reduce){
  
  coancest=NULL
  # Pull number of parents from either parents (if gen is 1) or last phenos if gen>1
  if(reduced){NumParents=length(OPparphenos)} else {NumParents=parentinfo$num.parents}
  
  if(SelfPar){
    par1 <- self.pars[seq(1,length(self.pars),2)]
    par2 <- self.pars[seq(2,length(self.pars),2)]
    prog.par <- rep(prog.percross,length(par1))
    crossdesign <- cbind(par1,par2,prog.par)
  }
  # Make Cross Design File Depending on Strategy
  if(AssortiveMating | selftest){
    total <- NumParents/4
    if(gen==1){
      sorted.ebvs <- OPparphenos
      relationshipmatrix <- as.data.frame(diag(1,nrow=NumParents,ncol=NumParents)); colnames(relationshipmatrix) <- names(OPparphenos); rownames(relationshipmatrix) <- names(OPparphenos)
      top.25 <- names(OPparphenos)[1:total]
      top.50 <- names(OPparphenos)[(total+1):(total*2)]
      bottom.50 <- names(OPparphenos)[(total*2+1):(total*3)]
      bottom.25 <- names(OPparphenos)[(total*3+1):(total*4)]
    } else {
      sorted.ebvs <- sort(parentinfo$select.EBVs,decreasing = T)
      relationshipmatrix <- parentinfo$relmat[which(colnames(parentinfo$relmat) %in% names(sorted.ebvs)),which(colnames(parentinfo$relmat) %in% names(sorted.ebvs))]
      top.25 <- names(sorted.ebvs)[1:total]
      top.50 <- names(sorted.ebvs)[(total+1):(total*2)]
      bottom.50 <- names(sorted.ebvs)[(total*2+1):(total*3)]
      bottom.25 <- names(sorted.ebvs)[(total*3+1):(total*4)]}
    
    all <- vector("list")
    for(i in 1:total){
      all[[i]] <- top.25[-i]
    }
    if(ancest.thresh){
      E <- upper.tri(relationshipmatrix); relationshipmatrix[E] <- NA
      coancestry <- seq(.01,1,.005)
      if(gen==1){
        for(i in 1:length(coancestry)){
          new <- subset(melt(as.matrix(t(relationshipmatrix))), value < coancestry[i])
          print(coancestry[i])
          matches1 <- match(new[,1],names(sorted.ebvs))
          matches2 <- match(new[,2],names(sorted.ebvs))
          a <- sorted.ebvs[matches1]
          b <- sorted.ebvs[matches2]
          new$mean.bv <- (a+b)/2
          new <- new[order(new$mean.bv,decreasing=T),]
          coancest <- coancestry[i]
          crossdesign <- matrix(NA,nrow=1,ncol=2)
          for(each in 1:length(top.25)){
            print(each)
            par <- top.25[each]
            options1 <-   which(new[,1] %in% par)
            options2 <-  which( new[,2] %in% par )
            options1.other <- options1[which(as.character(new[options1,2]) %in% all[[each]])]
            options2.other <- options2[which(new[options2,1] %in% all[[each]])]
            options <- sort(c(options1.other,options2.other))
            this.cross <- new[options[1:2],c(1:2)] ; colnames(this.cross) <- c("V1","V2")
            if(anyNA(this.cross)){break}
            crossdesign <- rbind(crossdesign,this.cross)
            if(each == 1){crossdesign <- crossdesign[-1,]}
            new <- new[-c(which(new[,1] %in% this.cross[,1] & new[,2] %in% this.cross[,2] )),]
          } 
          
          top50.samp <-top.50
          for(each in 1:length(top.25)){
            print(each)
            par <- top.25[each]
            options1 <-   which(new[,1] %in% par)
            options2 <-  which( new[,2] %in% par )
            options1.other <- options1[which(as.character(new[options1,2]) %in% top50.samp)]
            options2.other <- options2[which(new[options2,1] %in% top50.samp)]
            options <- sort(c(options1.other,options2.other))
            this.cross <- new[options[1],c(1:2)] ; colnames(this.cross) <- c("V1","V2")
            if(anyNA(this.cross)){break}
            crossdesign <- rbind(crossdesign,this.cross)
            new <- new[-c(which(new[,1] %in% this.cross[,1] & new[,2] %in% this.cross[,2] )),]
            top50.samp <- top50.samp[-c(which(top50.samp %in% this.cross[,1] | top50.samp %in% this.cross[,2]))]
          } 
          
          bottom50.samp <- bottom.50
          for(each in 1:length(top.25)){
            #print(each)
            par <- top.25[each]
            options1 <-   which(new[,1] %in% par)
            options2 <-  which( new[,2] %in% par )
            options1.other <- options1[which(as.character(new[options1,2]) %in% bottom50.samp)]
            options2.other <- options2[which(new[options2,1] %in% bottom50.samp)]
            options <- sort(c(options1.other,options2.other))
            this.cross <- new[options[1],c(1:2)] ; colnames(this.cross) <- c("V1","V2")
            #if(anyNA(this.cross)){break}
            crossdesign <- rbind(crossdesign,this.cross)
            new <- new[-c(which(new[,1] %in% this.cross[,1] & new[,2] %in% this.cross[,2] )),]
            bottom50.samp <- bottom50.samp[-c(which(bottom50.samp %in% this.cross[,1] | bottom50.samp %in% this.cross[,2]))]
          } 
          
          bottom25.samp <- bottom.25
          for(each in 1:length(top.25)){
            #print(each)
            par <- top.50[each]
            options1 <-   which(new[,1] %in% par)
            options2 <-  which( new[,2] %in% par )
            options1.other <- options1[which(as.character(new[options1,2]) %in% bottom25.samp)]
            options2.other <- options2[which(new[options2,1] %in% bottom25.samp)]
            options <- sort(c(options1.other,options2.other))
            this.cross <- new[options[1],c(1:2)] ; colnames(this.cross) <- c("V1","V2")
            #if(anyNA(this.cross)){break}
            crossdesign <- rbind(crossdesign,this.cross)
            new <- new[-c(which(new[,1] %in% this.cross[,1] & new[,2] %in% this.cross[,2] )),]
            bottom25.samp <- bottom25.samp[-c(which(bottom25.samp %in% this.cross[,1] | bottom25.samp %in% this.cross[,2]))]
          } 
          
          bottom50.samp <- bottom.50
          for(each in 1:length(top.25)){
            #print(each)
            par <- top.50[each]
            options1 <-   which(new[,1] %in% par)
            options2 <-  which( new[,2] %in% par )
            options1.other <- options1[which(as.character(new[options1,2]) %in% bottom50.samp)]
            options2.other <- options2[which(new[options2,1] %in% bottom50.samp)]
            options <- sort(c(options1.other,options2.other))
            this.cross <- new[options[1],c(1:2)] ; colnames(this.cross) <- c("V1","V2")
            #if(anyNA(this.cross)){break}
            crossdesign <- rbind(crossdesign,this.cross)
            new <- new[-c(which(new[,1] %in% this.cross[,1] & new[,2] %in% this.cross[,2] )),]
            bottom50.samp <- bottom50.samp[-c(which(bottom50.samp %in% this.cross[,1] | bottom50.samp %in% this.cross[,2]))]
          } 
          
          if(!anyNA(crossdesign)){break}}
      } else {
        for(i in 1:length(coancestry)){
          new <- subset(melt(as.matrix(t(relationshipmatrix))), value < coancestry[i])
          print(coancestry[i])
          matches1 <- match(new[,1],names(sorted.ebvs))
          matches2 <- match(new[,2],names(sorted.ebvs))
          a <- sorted.ebvs[matches1]
          b <- sorted.ebvs[matches2]
          new$mean.bv <- (a+b)/2
          new <- new[order(new$mean.bv,decreasing=T),]
          coancest <- coancestry[i]
          crossdesign <- matrix(NA,nrow=1,ncol=2)
          for(each in 1:length(top.25)){
            #print(each)
            par <- top.25[each]
            options1 <-   which(new[,1] %in% par)
            options2 <-  which( new[,2] %in% par )
            options1.other <- options1[which(as.character(new[options1,2]) %in% all[[each]])]
            options2.other <- options2[which(new[options2,1] %in% all[[each]])]
            options <- sort(c(options1.other,options2.other))
            this.cross <- new[options[1:2],c(1:2)] ; colnames(this.cross) <- c("V1","V2")
            #if(anyNA(this.cross)){break}
            crossdesign <- rbind(crossdesign,this.cross)
            if(each == 1){crossdesign <- crossdesign[-1,]}
            new <- new[-c(which(new[,1] %in% this.cross[,1] & new[,2] %in% this.cross[,2] )),]
          } 
          
          top50.samp <-top.50
          for(each in 1:length(top.25)){
            #print(each)
            par <- top.25[each]
            options1 <-   which(new[,1] %in% par)
            options2 <-  which( new[,2] %in% par )
            options1.other <- options1[which(as.character(new[options1,2]) %in% top50.samp)]
            options2.other <- options2[which(new[options2,1] %in% top50.samp)]
            options <- sort(c(options1.other,options2.other))
            this.cross <- new[options[1],c(1:2)] ; colnames(this.cross) <- c("V1","V2")
            #if(anyNA(this.cross)){break}
            crossdesign <- rbind(crossdesign,this.cross)
            new <- new[-c(which(new[,1] %in% this.cross[,1] & new[,2] %in% this.cross[,2] )),]
            top50.samp <- top50.samp[-c(which(top50.samp %in% this.cross[,1] | top50.samp %in% this.cross[,2]))]
          } 
          #set.seed(34634)
          parent1.2.top25 <- sample(top.25,length(top.25),replace=F)
          #set.seed(343463634)
          parent2.2.bottom50 <- sample(bottom.50,length(top.25),replace=F)
          #set.seed(342278634)
          parent1.3.top50 <- sample(top.50,length(top.25),replace=F)
          #set.seed(334)
          parent2.3.bottom25 <- sample(bottom.25,length(top.25),replace=F)
          #set.seed(34994)
          parent1.4.top50 <- sample(top.50,length(top.25),replace=F)
          #set.seed(346512434)
          parent2.4.bottom50 <- sample(bottom.50,length(top.25),replace=F)
          all.other.crosses1 <- c(parent1.2.top25,parent1.3.top50,parent1.4.top50) 
          all.other.crosses2 <- c(parent2.2.bottom50,parent2.3.bottom25,parent2.4.bottom50)
          all.other.crosses <- cbind(all.other.crosses1,all.other.crosses2)
          colnames(all.other.crosses) <- c("V1","V2")
          crossdesign <- rbind(crossdesign,all.other.crosses)
          if(!anyNA(crossdesign)){break}}}
      
      
      crossdesign[,3] <- rep(prog.percross,nrow(crossdesign))
    }  else {
      parent2 <- vector()
      for(each in 1:length(top.25)){
        par1 <- each
        par2 <- sample(all[[each]],2,replace=F)
        parent2 <- c(parent2,par2)
        for(i in 1:length(par2)){
          all[[par2[i]]] <- all[[par2[i]]][-each]
        }}
      parent1.top25 <- rep(top.25,each=2)
      parent2.top25 <- parent2
      parent1.1.top25 <- sample(top.25,length(top.25),replace=F)
      parent2.1.top50 <- sample(top.50,length(top.25),replace=F)
      parent1.2.top25 <- sample(top.25,length(top.25),replace=F)
      parent2.2.bottom50 <- sample(bottom.50,length(top.25),replace=F)
      parent1.3.top50 <- sample(top.50,length(top.25),replace=F)
      parent2.3.bottom25 <- sample(bottom.25,length(top.25),replace=F)
      parent1.4.top50 <- sample(top.50,length(top.25),replace=F)
      parent2.4.bottom50 <- sample(bottom.50,length(top.25),replace=F)
      
      pars1 <- c(parent1.top25,parent1.1.top25,parent1.2.top25,parent1.3.top50,parent1.4.top50)
      
      pars2 <- c(parent2.top25,parent2.1.top50,parent2.2.bottom50,parent2.3.bottom25,parent2.4.bottom50)
      
      
      crossdesign <- cbind(par1=pars1,
                           par2=pars2,
                           prog=rep(prog.percross,length(pars1)))}}
  
  if ( RandomMating ){
    crossdesign= matrix(sample(names(parentinfo$selections),replace=FALSE, size=NumParents),nrow = NumParents/2,ncol=2)
    crossdesign <- cbind(crossdesign,rep(prog.percross,length(crossdesign[,1])))
  }  else if (SP.MateSelect ) { 
    par1 <- vector(); par2 <- vector()
    relationshipmatrix <- parentinfo$relmat[which(colnames(parentinfo$relmat) %in% parentinfo$select.ped.ids),which(colnames(parentinfo$relmat) %in% parentinfo$select.ped.ids)]
    E <- upper.tri(relationshipmatrix); relationshipmatrix[E] <- NA
    coancestry <- seq(.01,1,.005)
    for(i in 1:length(coancestry)){
      new <- subset(melt(as.matrix(t(relationshipmatrix))), value < coancestry[i])
      print(coancestry[i])
      matches1 <- match(new[,1],names(parentinfo$select.EBVs))
      matches2 <- match(new[,2],names(parentinfo$select.EBVs))
      a <- parentinfo$select.EBVs[matches1]
      b <- parentinfo$select.EBVs[matches2]
      new$mean.bv <- (a+b)/2
      new <- new[order(new$mean.bv,decreasing=T),]
      coancest <- coancestry[i]
      crossdesign <- matrix(NA,nrow=(NumParents/2),ncol=3)
      for(i in 1:(NumParents/2)) {
        crossdesign[i,1] <-  new[1,1]
        crossdesign[i,2] <-  new[1,2]
        crossdesign[i,3] <- prog.percross
        new <- new[which(new[,1] != crossdesign[i,1] & new[,1] != crossdesign[i,2]),]
        new <- new[which(new[,2] != crossdesign[i,1] & new[,2] != crossdesign[i,2]),]} 
      if (!anyNA(crossdesign)) {break}}
  } else if  (MP.MateSelect) {
    par1 <- vector()
    par2 <- vector()
    relationshipmatrix <- parentinfo$relmat[which(colnames(parentinfo$relmat) %in% parentinfo$select.ped.ids),which(colnames(parentinfo$relmat) %in% parentinfo$select.ped.ids)]
    D <- relationshipmatrix
    coancestry <- seq(.01,1,.005)
    for(i in 1:length(coancestry)){
      D[D < coancestry[i]] <- 0 
      D[D > coancestry[i]] <- 1
      D <- 1-D
      minimum <- colSums(D, na.rm=T)
      coancest <- coancestry[i]
      D <- relationshipmatrix
      #if(min(minimum) >= 90) break }
      sorted.minimum <- sort(minimum, decreasing=F)
      relationshipmatrix <- relationshipmatrix[,names(sorted.minimum)]
      E <- upper.tri(relationshipmatrix)
      relationshipmatrix[E] <- NA
      new <- subset(melt(as.matrix(t(relationshipmatrix))), value < coancest)
      matches1 <- match(new[,1],names(parentinfo$select.EBVs))
      matches2 <- match(new[,2],names(parentinfo$select.EBVs))
      a <- parentinfo$select.EBVs[matches1]
      b <- parentinfo$select.EBVs[matches2]
      new$mean.bv <- (a+b)/2
      sib1 <- sample(colnames(relationshipmatrix)[seq(1,NumParents,2)],NumParents/2)
      sib2 <- colnames(relationshipmatrix)[seq(2,NumParents,2)]
      test <- new[order(-new[,4]),]
      par1 <- test[1:(length(parentinfo$selections)/2),1]
      par2 <- test[1:(length(parentinfo$selections)/2),2]
      progeny <- rep(prog.percross, length(par1))
      crossdesign=matrix(data=c(par1,par2,progeny),nrow=length(progeny),ncol=3)
      if (!anyNA(crossdesign)) {break}}} else if (cross.file.input) {
        colClasses = c("integer", "integer", "integer")
        crossdesign = as.matrix(read.table(crossfile,header=F,sep="\t", colClasses))
      }
  
  numcrosses <- nrow(crossdesign)
  totalprogeny <- sum(as.numeric(crossdesign[,3]))
  par1list<-vector()
  par2list<-vector()
  par1id<-vector()
  par2id<-vector()
  generation<- rep(gen,totalprogeny)
  
  if (gen==1){
    totalindiv   <- totalprogeny+length(unique(c(crossdesign[,1],crossdesign[,2])))
    cumul.total <- length(unique(c(crossdesign[,1],crossdesign[,2]))) + totalprogeny
    indivIDs<-c(seq((parentinfo$num.parents+1),(parentinfo$num.parents)+(totalprogeny)))
    for (m in 1:numcrosses){
      crossprog<-as.numeric(crossdesign[m,3])
      par1<-as.character(crossdesign[m,1])
      par2<-as.character(crossdesign[m,2])
      par1list<-c(par1list,rep(par1,crossprog))
      par2list<-c(par2list,rep(par2,crossprog))}
    
    uni <- length(unique(c(crossdesign[,1],crossdesign[,2])))
    if(SelfPar){
      parentped <- cbind("ID"=rep(unique(c(crossdesign[,1],crossdesign[,2])),1),"Par1" = rep(0,uni), "Par2"= rep(0,uni),"gener"=rep(0,uni))
    } else{
      parentped <- cbind("ID"=rep(unique(c(crossdesign[,1],crossdesign[,2])),1),"Par1" = rep(0,uni), "Par2"= rep(0,uni),"gener"=rep(0,uni))
    }
    progped<-cbind("ID"=indivIDs[1:length(indivIDs)], "Par1"=par1list[1:length(par1list)],"Par2"=par2list[1:length(par1list)],"gener"=generation[1:length(generation)])
    full.ped <- rbind(parentped,progped)
    selection.pedigree <- full.ped
    
  } else {
    indivIDs<- c("indivIDs",seq(max(as.numeric(parentinfo$fullped[,1]))+1,max(as.numeric(parentinfo$fullped[,1]))+totalprogeny))
    cumul.total<- parentinfo$cumulative.total + totalprogeny
    vector2 <- parentinfo$select.ped.ids
    for (m in 1:numcrosses){
      crossprog<-as.numeric(crossdesign[m,3])
      par1<-c(crossdesign[m,1])
      par2<-c(crossdesign[m,2])
      #par1id<- (vector2[par1])
      #par2id<- (vector2[par2])
      par1list<-c(par1list,rep(as.vector(par1),crossprog))
      par2list<-c(par2list,rep(as.vector(par2),crossprog))}
    progped<-cbind("ID"=indivIDs[2:length(indivIDs)], "Par1"=par1list,"Par2"=par2list,"gener"=generation)
    full.ped <- rbind(parentinfo$fullped,progped)
    selection.pedigree <- rbind(parentinfo$ped,progped)
  }
  
  if(saveped) {
    pedfilename=paste(rep.num,mapinfo$date.time,prefix,"-pedigree.txt",sep="")
    write.table(progped,pedfilename, quote = F, row.names = F, col.names = T, sep=" ")}
  
  ###Imp that genos.3d is first in list item, and total progeny is next list item bc in createtgv routine it expects genos.3d as first element and total prog as second
  progeny<-list(crossdesign=crossdesign, total.progeny.number=totalprogeny, progeny.pedigree=progped, full.pedigree= full.ped, 
                numparents=parentinfo$num.parents, coancestry.threshold=coancest, selection.ped=selection.pedigree,
                numcrosses=numcrosses,crossprog=crossprog,namestem=mapinfo$date.time,cumul.total=cumul.total, parent.IDs=progped[,1])
  return(progeny)}
