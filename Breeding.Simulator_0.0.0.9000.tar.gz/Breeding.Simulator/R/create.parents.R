####Create Founder Parent Population####
create.Parents <- function(mapinfo=map,numparents=NumParents, max.delt.allele=MaxDeltAlleles, 
                           QTLsd=.5,save=Save,random=FALSE,rep.num=Rep,heterozygous.markers=F){
  totalloci <- mapinfo$total.loci.num  # Specifies the total # of loci by pulling from the map object
  locusnames <- mapinfo$genetic.map$loci  # Specifies locus names from map object
  all.MAFs <- mapinfo$genetic.map$MAF     # Assign all.MAFs as the minor allele frequencies in the map object
  totalQTL <- mapinfo$total.QTL.num    # Total number of qtl pulled from map object
  QTLSNPs <- mapinfo$QTLSNP.loci      # A vector of the loci which are snpqtl
  numSNPQTL <- mapinfo$total.SNPQTL.num  # the number of snpqtl pulled from map object
  numQTL <- totalQTL - numSNPQTL  # the number of additive qtl (rQTL)
  #all.Markers <- map$available.Markers      # A vector of loci which can potentially be markers
  QTLoci <- sort(mapinfo$rQTL.loci)    # A vector of the loci which are additive QTL
  all.Markers <- as.numeric(rownames(mapinfo$genetic.map)[-c(QTLSNPs,QTLoci)])
  num.markers <- length(all.Markers)  # the number of potential markers
  
  #  Sample rQTL values from two normal distributions with mean 0 and std deviation half of that specified by QTLsd variable
  #  Use 'ceiling' function for one distribution, 'floor' function for other, then add them together to get centered distribution
  Dist1 <- ceiling(rnorm((numQTL*2), 0, (QTLsd*(sqrt(2)/2)))); Dist2 <- floor(rnorm((numQTL*2), 0, (QTLsd*(sqrt(2)/2))))
  QTLalleles <- Dist1 + Dist2  # Vector contains the values for the rQTL alleles
  
  #  Create Dimension names for 2 arrays
  parIDs<-1:numparents; alleleIDs<-c("a1","a2")
  
  # Parents array holds both alleles for all parents
  # QTLSNP array holds the alleles for the loci of all parents under dominance control  
  parents<-array(rep(NA,totalloci*numparents*2), dim=c(totalloci,numparents,2),dimnames=list(locusnames,parIDs,alleleIDs))
  QTLSNParray<-array(0, dim=c(numSNPQTL,numparents,2),dimnames=list(QTLSNPs,parIDs,alleleIDs))
  
  #  Create empty vectors to hold either allele1 or allele2  for each parent
  allele1<-rep(NA, totalloci); allele2<-rep(NA, totalloci)
  
  # Assign deleterious alleles 
  available.delt1 <- QTLSNPs; available.delt2 <- QTLSNPs
  D.marker.genotypes <- vector(); R.marker.genotypes <- vector()
  for (i in 1:26){
    D.marker.genotypes <- c(D.marker.genotypes,paste(LETTERS[i],LETTERS, sep=""))
    R.marker.genotypes <-  c(R.marker.genotypes,paste(letters[i],letters, sep=""))
  }
  
  ratio <- (max.delt.allele/2)/numSNPQTL
  # For each parent assign them alleles
  while(anyNA(parents)){
    available.delt1 <- QTLSNPs
    for(par in 1:numparents){
      num.delt <- sample(0:(numSNPQTL*ratio),1) # pick a number of deleterious alleles for allele 1 for this parent
      if(num.delt > length(available.delt1)) {break}
      minor1 <- sample(available.delt1,num.delt)  # pick out of the avaiable deleterious alleles for this parent
      available.delt1 <- available.delt1[which(!available.delt1 %in% minor1 )] # this new list makes it so the next parent can't have any of these alleles at allele 1 positions
      major1 <- QTLSNPs[which(!QTLSNPs %in% minor1)]
      
      num.delt <- sample(0:(numSNPQTL*ratio),1)
      if(num.delt > length(available.delt1[which(!available.delt1 %in% minor1)])) {break}
      minor2 <- sample(available.delt1[which(!available.delt1 %in% minor1)],num.delt)
      available.delt1 <- available.delt1[which(!available.delt1 %in% minor2 )]
      
      
      major2 <- QTLSNPs[which(!QTLSNPs %in% minor2)]
      allele1[minor1]<-"c"            # minor allele is always "c", major allele is always "a"
      allele1[major1] <-"a"
      allele2[minor2]<-"c"
      allele2[major2]<-"a"
      
      rand1<-runif(num.markers, min=0, max=1) 
      rand2<-runif(num.markers, min=0, max=1)
      minor1<-all.Markers[which(all.MAFs[all.Markers] > rand1)]
      major1 <- all.Markers[which(!all.Markers %in% minor1)]
      minor2<-all.Markers[which(all.MAFs[all.Markers] > rand2)]
      major2 <- all.Markers[which(!all.Markers %in% minor2)]
      if(heterozygous.markers){
        all.Markers.allele1 <- all.Markers
        minor1 <- sample(all.Markers,size = length(all.Markers)/2,replace=F)
        major1 <- all.Markers[which(!all.Markers %in% minor1)]
        minor2<- major1
        major2 <- minor1
      }
      
      allele1[minor1] <- R.marker.genotypes[par]
      allele1[major1] <- D.marker.genotypes[par]
      allele2[minor2] <- R.marker.genotypes[par]
      allele2[major2] <- D.marker.genotypes[par]
      
      parents[,par,1]<-allele1
      parents[,par,2]<-allele2
      
      parents[QTLoci,par,1] <- sample(QTLalleles,numQTL)
      parents[QTLoci,par,2] <- sample(QTLalleles,numQTL)
      ## Write a copy of the SNP alleles at the SNPQTL into an array to use in calculating parental values
      QTLSNParray[,par,1]<-allele1[QTLSNPs]
      QTLSNParray[,par,2]<-allele2[QTLSNPs]
    }}
  
  
  # Output the snpqtls genotypes to a matrix
  parentSNPgenos <- matrix(paste(parents[QTLSNPs,,1],parents[QTLSNPs,,2],sep=""),nrow=numSNPQTL,ncol=numparents)
  dimnames(parentSNPgenos) <- list(locusnames[QTLSNPs],parIDs)
  
  # Output the marker gentoypes to a matrix
  parent.markers <- matrix(paste(parents[all.Markers,,1],parents[all.Markers,,2],sep=""),nrow=num.markers,ncol=numparents)
  dimnames(parent.markers) <- list(locusnames[all.Markers],parIDs)
  
  
  result.parent <- sapply(rep(1:numparents,1),function(x) length(which(parentSNPgenos[,x]=="ac" | parentSNPgenos[,x]=="ca" | parentSNPgenos[,x]=="cc")))
  result.parent <- unlist(result.parent)
  # If save is true then then we save the parentSNPgenos object and parent.markers object
  if(save) {
    parfilename=paste(rep.num,"parent-SNPQTL-genotypes.txt")
    write.table(parentSNPgenos,parfilename, quote = F, row.names = T, col.names = T, sep= "\t")
    
    parfilename=paste(rep.num,"parent-marker-genotypes.txt")
    write.table(parent.markers,parfilename, quote = F, row.names = T, col.names = T, sep= "\t")    
  }
  
  ###IMP that genos.3d is first list element and numparents is second becuase that is what createTGV routine expects###
  parentinfo<-list(genos.3d=parents,delt.allele=result.parent,num.parents=numparents, parent.SNPQTL.matrix=parentSNPgenos, parent.Marker.matrix=parent.markers, parent.IDs=parIDs)
  cat("The returned object is a list containing a 3-D array of parent genotypes\n")
  cat("a matrix of parent SNP genotypes with individuals in columns, a scalar of the number of parents,\n")
  cat("matrices of the parental genotypes at all SNPs, parental QTL allele values, genotypes and values at SNP QTL,\n")
  cat("two matrices with variances of QTL alleles & genetic values and SNP QTL alleles & genetic values, and a list \n")
  cat("of the numerical values assigned to major and minor alleles at SNP-QTL in the parents.\n")
  return(parentinfo)
  # # # # #    End of function    # # # # # # # #
}
