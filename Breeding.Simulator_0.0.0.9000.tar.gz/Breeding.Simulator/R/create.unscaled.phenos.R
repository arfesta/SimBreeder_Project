#' Create Phenos
#'
#' This function allows you to create unscaled phenotypes
#' @param h2 heritabilty
#' @keywords extract genos from make crosses
#' @export
#' @examples
#' create.phenos()

####Create Unscaled Phenos####
create.phenos <- function(h2=Heritability, E.var= Env.var, gen=gen, TGV=parents.TGV, prog.percross=num.prog.percross,
                                   folder=Rep,namestem=map$date.time,crossdesign=cross.design$crossdesign ) {
  
  geneticvals<-TGV$genetic.values
  totalindiv<-length(geneticvals)
  phenos<-vector(length=totalindiv)
  trueh<-vector()
  
  if(gen==0){
    phenos <- geneticvals + rnorm(totalindiv,mean = 0,sd = sqrt(var(geneticvals)/.1))
    trueh <- round(var(geneticvals)/var(phenos),2)
    print(trueh)
    Env <- NULL
  } else  {
    first <- 1
    last <- prog.percross
    phenos <- vector(); Env <- vector()
    #for(i in 1:nrow(crossdesign)){
    E <- E.var
    #env <- rnorm(length(geneticvals[first:last]),mean = 0,sd = E)
    env <- rnorm(length(geneticvals),mean = 0,sd = E)
    #p <- geneticvals[first:last] + env
    #p <- geneticvals[first:last] + 100
    p <- geneticvals + env
    first <- last +1
    last <- first + prog.percross - 1
    #phenos <- c(phenos,p)
    phenos <- p
    Env <- c(Env,E)
    #}
    trueh <- var(geneticvals)/var(phenos)
    print(trueh)
  } 
  
  pheno.info<-list(phenos=phenos, genetic.values=geneticvals, E.var = Env)
  return(pheno.info)
}
