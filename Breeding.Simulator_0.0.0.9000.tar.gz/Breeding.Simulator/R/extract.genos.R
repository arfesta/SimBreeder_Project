#' Extract Genos for net generation
#'
#' This function allows you to extract the selections for the next generation
#' @param makecroses parents tgv required
#' @keywords extract genos from make crosses
#' @export
#' @examples
#' create.genos()


####Extract Genos####
create.genos <- function(mapinfo=map,crossdesign=cross.design$crossdesign,progeny=progeny1,num.prog.percross=prog.percross) {
  numprog <- as.numeric(crossdesign[1,3]) * 2 * nrow(crossdesign)
  x <- seq(1,numprog,as.numeric(crossdesign[1,3]))
  y <- seq(1,(nrow(crossdesign)*2),2)
  z <- seq(2,(nrow(crossdesign)*2),2)
  x.y <- x[y]
  x.z <- x[z]
  d <- NULL
  e <- NULL
  for( i in 1:length(x.y)) {
    d <- c(d,seq(x.y[i],(x.y[i]+num.prog.percross-1)))
    e <- c(e,seq(x.z[i],(x.z[i]+num.prog.percross-1)))
  }
  
  yo.1 <- data.frame(progeny[c(1:nrow(crossdesign))])[,d]
  yo.2 <- data.frame(progeny[c(1:nrow(crossdesign))])[,e]
  genos.3d <- abind(yo.1,yo.2, along=3)
  
  result <- sapply(1:num.prog.percross,function(x) {out <-length(which(genos.3d[mapinfo$QTLSNP.loci,,1][,x]=="c")); out2 <- length(which(genos.3d[mapinfo$QTLSNP.loci,,2][,x]=="c"))
  outer <- out+out2})
  result <- unlist(result)
  out <- list(genos.3d=genos.3d, delt.allles=result)
  return(out)}
