#' Make crosses among individuals
#'
#' This function allows you to make the crosses
#' @param crossfile input of crossfile
#' @keywords make.crosses
#' @export
#' @examples
#' make.crosses()


####Create Make Crosses####
make.crosses <- function(x,mapinfo=map,parentinfo=parents, cumul.total=parentinfo$cumulative.total, num.prog.percross=prog.percross,
                        crossfile=CrossFile1, savegenos=Save,saveped=Save,prefix=prefix,rep.num=Rep, cross.file=as.matrix(crossfile),
                        numchromos=num.chromos,c.design=cross.design$crossdesign, ...){
  #c.design <- c.design[x,]
  NumParents=parentinfo$num.parents # Pull number of parents from either parents (if gen is 1) or last phenos if gen>1
  chromoloci <- mapinfo$last.locus.per.chrom   # The last number of each loci for all chromsomes
  QTLSNPs      <- mapinfo$QTLSNP.loci # Vector of loci which are snpqtl
  m <- mapinfo$genetic.map
  
  par1<-match(x[1],colnames(parentinfo$genos.3d)) # assigns par1 to be the first parent in crossdesign matrix
  par2<-match(x[2],colnames(parentinfo$genos.3d)) # assigns par2 to be the second parent in the crossdesign matrix
  crossprog<-as.numeric(x[3]) #assigns number of progeny to be the third column for cross "X"
  
  #par1<-match(x[1],colnames(parentinfo$genos.3d)) # assigns par1 to be the first parent in crossdesign matrix
  #par2<-match(x[2],colnames(parentinfo$genos.3d)) # assigns par2 to be the second parent in the crossdesign matrix
  #crossprog<-as.numeric(x[3]) #assigns number of progeny to be the third column for cross "X"
  
  # Create empty matrix to hold gametes
  # dimensions are (total # of loci) x  (# of cross progeny)
  # rownames are the loci names
  gametes1<-matrix(rep(NA,mapinfo$total.loci.num*crossprog),nrow=mapinfo$total.loci.num,ncol=crossprog,dimnames=list(mapinfo$map$loci,NULL))
  gametes2<-matrix(rep(NA,mapinfo$total.loci.num*crossprog),nrow=mapinfo$total.loci.num,ncol=crossprog,dimnames=list(mapinfo$map$loci,NULL))
  
  par1.alleles <- (parentinfo$genos.3d[,par1,])
  par2.alleles <- (parentinfo$genos.3d[,par2,])
  chr.ind.r <- vector("list")
  for(each in 1:crossprog){
    first.pos <- 1
    ch.r <- vector("list")
    for(i in 1:length(chromoloci)){
      last.pos <- chromoloci[i]
      t <- sample(seq(0,1,.0001),chromoloci[1],replace = T)
      l <- which(t < m[first.pos:last.pos,7])
      while(length(l) < 1){t <- sample(seq(0,1,.0001),chromoloci[1],replace = T)
      l <- which(t < m[first.pos:last.pos,7])}
      if(length(l) > 2){ l <- l[1:2]} else{l <- l}
      ch.r[[i]] <- seq(first.pos,last.pos,1)[l]
      first.pos <- last.pos+ 1
    }
    chr.ind.r[[each]] <- unlist(ch.r)}
  
  for(i in 1:crossprog) {
    allele <- sample(1:2,1)
    end <- chromoloci[numchromos]
    z <-1
    recombination.spots <- chr.ind.r[[i]]
    for (each in 1:length(recombination.spots)) {
      if (each < length(recombination.spots)){
        gametes1[z:recombination.spots[each]-1,i] <- par1.alleles[z:recombination.spots[each]-1,allele]
      } else { gametes1[z:end,i] <- par1.alleles[z:end,allele] }
      if (allele==1) { allele <- allele +1 } else { allele <- allele -1}
      z <- recombination.spots[each]
    }}
  
  chr.ind.r <- vector("list")
  for(each in 1:crossprog){
    first.pos <- 1
    ch.r <- vector("list")
    for(i in 1:length(chromoloci)){
      last.pos <- chromoloci[i]
      t <- sample(seq(0,1,.0001),chromoloci[1],replace = T)
      l <- which(t < m[first.pos:last.pos,7])
      while(length(l) < 1){t <- sample(seq(0,1,.0001),chromoloci[1],replace = T)
      l <- which(t < m[first.pos:last.pos,7])}
      if(length(l) > 2){ l <- l[1:2]} else{l <- l}
      ch.r[[i]] <- seq(first.pos,last.pos,1)[l]
      first.pos <- last.pos+ 1
    }
    chr.ind.r[[each]] <- unlist(ch.r)}
  
  for(i in 1:crossprog) {
    allele <- sample(1:2,1)
    end <- chromoloci[numchromos]
    z <-1
    recombination.spots <- chr.ind.r[[i]]
    for (each in 1:length(recombination.spots)) {
      if (each < length(recombination.spots)){
        gametes2[z:recombination.spots[each]-1,i] <- par2.alleles[z:recombination.spots[each]-1,allele]
      } else { gametes2[z:end,i] <- par2.alleles[z:end,allele] }
      if (allele==1) { allele <- allele +1 } else { allele <- allele -1}
      z <- recombination.spots[each]
    }}
  array.out <- abind(gametes1,gametes2,along=3)
  out <- list(as.array(array.out))
}
