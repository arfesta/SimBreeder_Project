#' Extract Selections for net generation
#'
#' This function allows you to extract the selections for the next generation
#' @param parents.TGV parents tgv required
#' @keywords extract.selections
#' @export
#' @examples
#' extract.selections()


####Extract Selections####
extract.selections <- function(parents.tgv=parents.TGV, past.phenos=parents.phenos, gen=1,prog.percross=num.prog.percross,
                               progenyinfo=progeny1, progenyTGV=progeny1.TGV, progenyphenos=progeny1.phenos,
                               #Selection types and Methods
                               numSelections = num.Selections,Selfed.progeny=selfed.progeny, assortivemating=assortive.mating,
                               sbpm=SBPM, sbpw=SBPW,selftest=SELFTEST, gblup=GBLUP,ablup=ABLUP, hblup=HBLUP, p=P,withininfamilygblup=within.family.gblup,
                               #Constants
                               mapinfo=map,h2=Heritability, crossdesign.inuse=cross.design, E.var = Env.var,
                               prefix=prefix,rep.num=Rep,pars=s.12,SelfPar=self.par,reduced=reduce) {
  
  # Extracting crossdesign, number of parents, complete(full) & progeny pedigree from progenyinfo object
  crossdesign <- crossdesign.inuse$crossdesign
  prog.pedigree <- crossdesign.inuse$progeny.pedigree[which(crossdesign.inuse$progeny.pedigree[,2] != crossdesign.inuse$progeny.pedigree[,3]),]
  numparents <- crossdesign.inuse$numparents
  full.ped <- crossdesign.inuse$full.pedigree
  selection.ped <- data.frame(crossdesign.inuse$selection.ped)
  
  # Extracting parent markers, progeny tgv & markers, as well as creating marker map from progenyTGV object
  if (gen==1){
    if(reduced){
      parent.markers <- parents.tgv$markers.matrix[as.numeric(names(pars)),]
    } else { parent.markers <- parents.tgv$markers.matrix}} else {parent.markers <- past.phenos$all.markers}
  prog.markers <- progenyTGV$markers.matrix
  progeny.phenos <- progenyphenos$phenos
  prog.genetic.values <- progenyTGV$genetic.values
  map.markers <- progenyTGV$marker.map
  colnames(map.markers) <- c("chr","pos")
  map.markers$chr <- as.character(map.markers$chr)
  
  # Generate pedigree using synbreed if 1st gen otherwise just use full.ped object
  # Create 2 objects which hold all markers and all phenotypes respectively
  if (gen==1) {
    ped <- create.pedigree(ID=full.ped[,1],full.ped[,2],full.ped[,3],full.ped[,4])
    all.markers <- rbind(parent.markers,prog.markers)
    if(SelfPar | reduced){  all.phenos <- c(past.phenos$phenos[as.numeric(names(pars))],progeny.phenos)
    all.genetic.vals <- c(past.phenos$genetic.values[as.numeric(names(pars))],prog.genetic.values)
    } else { all.phenos <- c(past.phenos$phenos,progeny.phenos)
    all.genetic.vals <- c(past.phenos$genetic.values,prog.genetic.values)}
  } else {
    ped <- create.pedigree(ID=selection.ped[,1],selection.ped[,2],selection.ped[,3],selection.ped[,4])
    all.markers <- rbind(parent.markers,prog.markers)
    all.phenos <- c(past.phenos$all.phenos,progeny.phenos)
    all.genetic.vals <- c(past.phenos$genetic.values,prog.genetic.values)
  }
  ped <- ped[order(as.numeric(ped$ID)),]
  
  # Pepare for Selection Extraction
  # Make Selections based on type and method
  # Types: SBPM, SBPW, SELFP, SELFL
  # Methods: Phenotype, ABLUP, GBLUP
  
  
  first.in.family <- 1
  Selections <- vector()
  if.within.g.Selections <- vector()
  Capital.genotypes <- vector(); Lowercase.genotypes <- vector()
  for (i in 1:26){
    Capital.genotypes <- c(Capital.genotypes,paste(LETTERS[i],LETTERS,LETTERS[i],LETTERS, sep=""))
    Lowercase.genotypes <-  c(Lowercase.genotypes,paste(letters[i],letters, letters[i], letters, sep=""))}
  if (selftest) {
    if (ablup){
      c.ped <- cbind(ped[,1:3],y=all.phenos)
      c.ped <- data.frame(c.ped)
      colnames(c.ped) <- c("ID","SIRE","DAM","y")
      c.ped[,1] <- as.integer(c.ped[,1])
      c.ped[,2] <- as.numeric(c.ped[,2])
      c.ped[,3] <- as.numeric(c.ped[,3])
      c.ped[,4] <- as.numeric(c.ped[,4])
      c.ped <- data.frame(c.ped)
      
      sol1 <- blup(y ~ 1,ped=c.ped,alpha = 9)
      phenos.1 <- as.matrix(all.phenos); colnames(phenos.1) <- "Vol"
      gp <- create.gpData(pheno=phenos.1,pedigree=ped);
      ADD.Rel.Mat <- kin(gp,ret="add") ; rel.mat <- data.frame(ADD.Rel.Mat); colnames(rel.mat) <- ped[,1]
      #PBLUP <- gpMod(gp, model="BLUP", trait = "Vol", kin=ADD.Rel.Mat, markerEffects=F,predict=F)
      #  g <- match(names(progenyphenos$phenos),rownames(PBLUP$fit$predicted)) 
      #  progeny.blups <- PBLUP$fit$predicted[g] ; names(progeny.blups) <- names(progenyphenos$phenos) 
      g <- match(names(progenyphenos$phenos),rownames(sol1)) 
      gprogeny.blups <- sol1[g,1] ; names(gprogeny.blups) <- names(progenyphenos$phenos) 
      
      first <- 1
      last <- prog.percross
      mean.progeny.blups <- vector()
      for(each in 1:nrow(crossdesign)){
        mean.progeny.blups <- c(mean.progeny.blups,mean(gprogeny.blups[first:last]))
        first <- last+1
        last <- first+prog.percross-1
      }
      #hist(mean.progeny.blups)
      sorted.mean.progeny.blups <- sort(mean.progeny.blups,decreasing=T)
      if(reduced){
        top.280.families <- which(mean.progeny.blups %in% sorted.mean.progeny.blups[1:length(pars)])} else {top.280.families <- which(mean.progeny.blups %in% sorted.mean.progeny.blups)}
    }
    
    if (gblup){
      class(all.markers) <- "numeric"
      if(withininfamilygblup){
        progeny.blups <- lapply(1:length(crossdesign[,1]),function(x){
          par1 <- crossdesign[x,1]
          par2 <- crossdesign[x,2]
          prog <- which(ped[,2] %in% par1 & ped[,3] %in% par2)
          fam.ped <- ped[prog,]
          fam.phenos <- all.phenos[match(fam.ped[,1],names(all.phenos))]
          fam.markers <- all.markers[match(fam.ped[,1],rownames(all.markers)),]
          c.ped <- cbind(fam.ped[,1:3],y=fam.phenos)
          colnames(c.ped) <- c("ID","SIRE","DAM","y")
          c.ped[,1] <- as.integer(c.ped[,1])
          c.ped[,2] <- as.numeric(c.ped[,2])
          c.ped[,3] <- as.numeric(c.ped[,3])
          c.ped[,4] <- as.numeric(c.ped[,4])
          c.ped <- data.frame(c.ped)
          sol <- gblup(y ~ 1,data=c.ped[,c(1,4)],M=fam.markers,lambda = 9)
          g <- which( rownames(sol) %in% names(progenyphenos$phenos)) 
          sol[g,1]
        })
        progeny.blups <- unlist(progeny.blups)
        names(progeny.blups) <- names(progenyphenos$phenos) 
      } else {
        
        c.ped <- cbind(ped[,1:3],y=all.phenos)
        c.ped <- data.frame(c.ped)
        colnames(c.ped) <- c("ID","SIRE","DAM","y")
        c.ped[,1] <- as.integer(c.ped[,1])
        c.ped[,2] <- as.numeric(c.ped[,2])
        c.ped[,3] <- as.numeric(c.ped[,3])
        c.ped[,4] <- as.numeric(c.ped[,4])
        sol <- gblup(y ~ 1,data=c.ped[,c(1,4)],M=fam.markers,lambda = 9)
        g <- match(names(progenyphenos$phenos),rownames(sol)) 
        progeny.blups <- sol[g,1] ; names(progeny.blups) <- names(progenyphenos$phenos)} 
      
      #phenos.1 <- as.matrix(all.phenos); colnames(phenos.1) <- "Vol"
      #gp <- create.gpData(pheno=phenos.1, pedigree=ped)
      #A.Rel.Mat <- kin(gp,ret="add"); rel.mat <- data.frame(A.Rel.Mat); colnames(rel.mat) <- ped[,1]
      
      #first <- 1
      #last <- prog.percross
      #mean.progeny.blups <- vector()
      #for(each in 1:nrow(crossdesign)){
      #  mean.progeny.blups <- c(mean.progeny.blups,mean(progeny.blups[first:last]))
      #  first <- last+1
      #  last <- first+prog.percross-1
      #}
      #hist(mean.progeny.blups)
      #sorted.mean.progeny.blups <- sort(mean.progeny.blups,decreasing=T)
      #if(reduce){
      #  top.280.families <- which(mean.progeny.blups %in% sorted.mean.progeny.blups[1:length(pars)])} else {top.280.families <- which(mean.progeny.blups %in% sorted.mean.progeny.blups)}
    }
    
    for (each.cross in 1:length(top.280.families)){
      yo <- vector(mode="list",length=as.numeric(crossdesign[1,3]))
      yoo <- vector(mode="list",length=crossdesign[1,3])
      yo.1 <- vector(mode="list",length=crossdesign[1,3])
      yoo.1 <- vector(mode="list",length=crossdesign[1,3])
      cross <- top.280.families[each.cross]
      parent1 <- as.numeric(crossdesign[cross,1])
      parent2 <- as.numeric(crossdesign[cross,2])
      print(parent2)
      if(reduced){first.in.family <- (as.numeric(crossdesign[cross,3])*cross) - prog.percross + 1
      num.prog <- seq(first.in.family,first.in.family + prog.percross -1)} else {
        num.prog <- seq(first.in.family,first.in.family + prog.percross -1)}
      # if (gen==1){
      #  parent1.alleles <- progenyinfo$genos.3d[as.numeric(names(Selfed.progeny[[parent1]]$top.indiv)),num.prog,1]
      #  parent2.alleles <- progenyinfo$genos.3d[as.numeric(names(Selfed.progeny[[parent2]]$top.indiv)),num.prog,2]
      #  top.parent.1 <- Selfed.progeny[[parent1]]$top.indiv
      #  top.parent.2 <- Selfed.progeny[[parent2]]$top.indiv
      #  } else {
      parent1.alleles <-  progenyinfo$genos.3d[as.numeric(names(Selfed.progeny[[which(names(Selfed.progeny) %in% parent1)]]$top.indiv)),num.prog,1]
      parent2.alleles <-  progenyinfo$genos.3d[as.numeric(names(Selfed.progeny[[which(names(Selfed.progeny) %in% parent2)]]$top.indiv)),num.prog,2]  
      top.parent.1 <- Selfed.progeny[[which(names(Selfed.progeny) %in% parent1)]]$top.indiv
      top.parent.2 <- Selfed.progeny[[which(names(Selfed.progeny) %in% parent2)]]$top.indiv
      #}
      for(i in 1:prog.percross){
        yo[[i]] <- which(parent1.alleles[,i]==top.parent.1)
        yoo[[i]] <- sum(Selfed.progeny[[which(names(Selfed.progeny) %in% as.character(parent1))]]$most.imp[yo[[i]]])
        yo.1[[i]] <- which(parent2.alleles[,i]==top.parent.2)
        yoo.1[[i]] <- sum(Selfed.progeny[[which(names(Selfed.progeny) %in% as.character(parent2))]]$most.imp[yo.1[[i]]])
      }
      total <- mapply(function(x1,y1) x1[[1]] + y1[[1]], yoo, yoo.1)
      select.from.fam <- names(sort(rank(total)*0 + rank(-progeny.blups[num.prog]))[1])
      select.from.fam.if.g <- names(sort(rank(total)*0 + rank(-gprogeny.blups[num.prog]))[1])
      Selections <- c(Selections,select.from.fam)
      if.within.g.Selections <- c(if.within.g.Selections,select.from.fam.if.g)
      #Selections <- c(Selections,num.prog[which(lengths(mapply(c,yo,yo.1,SIMPLIFY=F), use.names = FALSE) %in% sort(lengths(mapply(c,yo,yo.1,SIMPLIFY=F), use.names = FALSE),decreasing=T)[1:2])][1:2])
      first.in.family <- max(num.prog) + 1
    }
    g <- which( names(progenyphenos$phenos) %in% Selections) 
    Selections <- g
  }
  
  if (assortivemating){
    if (ablup){
      #c.ped <- cbind(ped[,1:3],y=all.phenos[match(ped[,1],names(all.phenos))])
      #c.ped <- data.frame(c.ped)
      #colnames(c.ped) <- c("ID","SIRE","DAM","y")
      pr.ped <- create.pedigree(ID=prog.pedigree[,1],prog.pedigree[,2],prog.pedigree[,3])
      c.ped <- cbind(pr.ped[,1:3],y=progeny.phenos[match(pr.ped[,1],names(progeny.phenos))])
      c.ped <- data.frame(c.ped)
      
      sol1 <- blup(y ~ 1,ped=c.ped,alpha = (E.var^2)/var(progeny.phenos))
      g <- match(names(progenyphenos$phenos),rownames(sol1)) 
      #g <- match(rownames(sol1),names(progenyphenos$phenos))
      aprogeny.blups <- sol1[g,1] ; names(aprogeny.blups) <- names(progenyphenos$phenos) 
      
      
      first <- 1
      last <- prog.percross
      mean.progeny.blups <- vector()
      for(each in 1:nrow(crossdesign)){
        mean.progeny.blups <- c(mean.progeny.blups,mean(aprogeny.blups[first:last]))
        first <- last+1
        last <- first+prog.percross-1
      }
      sorted.mean.progeny.blups <- sort(mean.progeny.blups,decreasing=T)
      if(reduced){
        top.280.families <- match(sorted.mean.progeny.blups[1:length(pars)], mean.progeny.blups)} else {top.280.families <- match(sorted.mean.progeny.blups, mean.progeny.blups)}
    }
    
    if (gblup){
      class(all.markers) <- "numeric"
      if(withininfamilygblup){
        ncross <- length(crossdesign[,1])
        first.prog <- seq(from=1,to = (ncross*prog.percross)+1,by = prog.percross )
        last.prog  <- seq(from=prog.percross,to= (ncross*prog.percross),by=prog.percross)
        gprogeny.blups <- lapply(1:length(crossdesign[,1]),function(x){
          par1 <- crossdesign[x,1]
          par2 <- crossdesign[x,2]
          prog <- which(ped[,2] %in% par1 & ped[,3] %in% par2)
          fam.ped <- ped[prog,]
          fam.phenos <- all.phenos[match(fam.ped[,1],names(all.phenos))]
          fam.markers <- all.markers[match(fam.ped[,1],rownames(all.markers)),]
          c.ped <- cbind(fam.ped[,1:3],y=fam.phenos)
          colnames(c.ped) <- c("ID","SIRE","DAM","y")
          sol <- gblup(y ~ 1,data=c.ped[,c(1,4)],M=fam.markers,lambda = (E.var^2)/var(progeny.phenos))
          #sol <- gblup(y ~ 1,data=c.ped[,c(1,4)],M=fam.markers,lambda = (var(progeny.phenos[first.prog[x]:last.prog[x]])-var(prog.genetic.values[first.prog[x]:last.prog[x]]))/var(prog.genetic.values[first.prog[x]:last.prog[x]]))
          g <- which( rownames(sol) %in% names(progeny.phenos)) 
          sol[g,1]
        })
        gprogeny.blups <- unlist(gprogeny.blups)
        names(gprogeny.blups) <- names(progeny.phenos) 
      } else {
        
        c.ped <- cbind(ped[,1:3],y=all.phenos)
        c.ped <- data.frame(c.ped)
        colnames(c.ped) <- c("ID","SIRE","DAM","y")
        
        sol <- gblup(y ~ 1,data=c.ped[,c(1,4)],M=fam.markers,lambda = 9)
        g <- match(names(progenyphenos$phenos),rownames(sol)) 
        progeny.blups <- sol[g,1] ; names(progeny.blups) <- names(progenyphenos$phenos)} 
      
      #phenos.1 <- as.matrix(all.phenos); colnames(phenos.1) <- "Vol"
      #gp <- create.gpData(pheno=phenos.1, pedigree=ped)
      #A.Rel.Mat <- kin(gp,ret="add"); rel.mat <- data.frame(A.Rel.Mat); colnames(rel.mat) <- ped[,1]
      
      #first <- 1
      #last <- prog.percross
      #mean.progeny.blups <- vector()
      #for(each in 1:nrow(crossdesign)){
      #  mean.progeny.blups <- c(mean.progeny.blups,mean(gprogeny.blups[first:last]))
      #  first <- last+1
      #  last <- first+prog.percross-1
      #}
      #hist(mean.progeny.blups)
      #sorted.mean.progeny.blups <- sort(mean.progeny.blups,decreasing=T)
      #if(reduced){
      #  top.280.families <- match(sorted.mean.progeny.blups[1:length(pars)], mean.progeny.blups)} else {top.280.families <- match(sorted.mean.progeny.blups, mean.progeny.blups)}
    }
    Selections <- vector()
    first.in.family <- 1
    for(family in 1:length(crossdesign[,3])){
      num.offspring <- as.numeric(crossdesign[family,3])
      last.in.family <- num.offspring + first.in.family - 1
      temp <- (gprogeny.blups[first.in.family:last.in.family]) ; sorted <-sort(temp,decreasing=TRUE)
      BestOne <- which(temp==sorted[1]) ; selected <- BestOne + first.in.family - 1 ;Selections <- c(Selections, selected)
      first.in.family <- last.in.family + 1 } 
    Selections <- Selections[top.280.families]
    
    #if.other.Selections <- vector()
    #first.in.family <- 1
    #for(family in 1:length(crossdesign[,3])){
    #  num.offspring <- as.numeric(crossdesign[family,3])
    #  last.in.family <- num.offspring + first.in.family - 1
    #  temp <- (aprogeny.blups[first.in.family:last.in.family]) ; sorted <-sort(temp,decreasing=TRUE)
    #  BestOne <- which(temp==sorted[1]) ; selected <- BestOne + first.in.family - 1 ;if.other.Selections <- c(if.other.Selections, selected)
    #  first.in.family <- last.in.family + 1 } 
    #if.other.Selections <- if.other.Selections[top.280.families]
    
  }
  
  
  if(sbpw){
    if (ablup){
      c.ped <- cbind(ped[,1:3],y=all.phenos)
      c.ped <- as.data.frame.matrix(c.ped)
      colnames(c.ped) <- c("ID","SIRE","DAM","y")
      c.ped[,1] <- as.integer(c.ped[,1])
      c.ped[,2] <- as.numeric(c.ped[,2])
      c.ped[,3] <- as.numeric(c.ped[,3])
      c.ped[,4] <- as.numeric(c.ped[,4])
      c.ped <- data.frame(c.ped)
      
      sol1 <- blup(y ~ 1,ped=c.ped,alpha = 9)
      phenos.1 <- as.matrix(all.phenos); colnames(phenos.1) <- "Vol"
      gp <- create.gpData(pheno=phenos.1,pedigree=ped);
      ADD.Rel.Mat <- kin(gp,ret="add") ; rel.mat <- data.frame(ADD.Rel.Mat); colnames(rel.mat) <- ped[,1]
      #PBLUP <- gpMod(gp, model="BLUP", trait = "Vol", kin=ADD.Rel.Mat, markerEffects=F,predict=F)
      #  g <- match(names(progenyphenos$phenos),rownames(PBLUP$fit$predicted)) 
      #  progeny.blups <- PBLUP$fit$predicted[g] ; names(progeny.blups) <- names(progenyphenos$phenos) 
      g <- match(names(progenyphenos$phenos),rownames(sol1)) 
      progeny.blups <- sol1[g,1] ; names(progeny.blups) <- names(progenyphenos$phenos) 
    }  
    if (gblup){
      class(all.markers) <- "numeric"
      c.ped <- cbind(ped[,1:3],y=all.phenos)
      c.ped <- data.frame(c.ped)
      colnames(c.ped) <- c("ID","SIRE","DAM","y")
      c.ped[,1] <- as.integer(c.ped[,1])
      c.ped[,2] <- as.numeric(c.ped[,2])
      c.ped[,3] <- as.numeric(c.ped[,3])
      c.ped[,4] <- as.numeric(c.ped[,4])
      sol <- gblup(y ~ 1,data=c.ped[,c(1,4)],M=all.markers,lambda = 9)
      #test <- all.markers-1
      #A <- A.mat(test)
      #data <- data.frame(y=all.phenos,gid=as.numeric(rownames(all.markers)))
      #t <- proc.time()
      #ans <- kin.blup(data,geno="gid",pheno="y",K=A)
      
      phenos.1 <- as.matrix(all.phenos); colnames(phenos.1) <- "Vol"
      gp <- create.gpData(pheno=phenos.1, pedigree=ped)
      #G.Rel.Mat <- kin(gp,ret="realized"); A.Rel.Mat <- kin(gp,ret="add"); rel.mat <- data.frame(A.Rel.Mat); colnames(rel.mat) <- ped[,1]
      A.Rel.Mat <- kin(gp,ret="add"); rel.mat <- data.frame(A.Rel.Mat); colnames(rel.mat) <- ped[,1]
      #t <- proc.time()
      #GBLUP <- gpMod(gp, model="BLUP", trait = "Vol", kin=G.Rel.Mat, predict=T, markerEffects=F)
      #proc.time()-t
      #g <- match(names(progenyphenos$phenos),rownames(GBLUP$fit$predicted))
      #progeny.blups <- GBLUP$fit$predicted[g]; names(progeny.blups) <- names(progenyphenos$phenos)
      #progeny.blups <- ans$g[which(names(ans$g) %in% names(progenyphenos$phenos))]
      g <- match(names(progenyphenos$phenos),rownames(sol)) 
      progeny.blups <- sol[g,1] ; names(progeny.blups) <- names(progenyphenos$phenos) 
    }
    #Selections within each family
    for(family in 1:length(crossdesign[,3])){
      num.offspring <- as.numeric(crossdesign[family,3])
      last.in.family <- num.offspring + first.in.family - 1
      if(p) {temp <- (progeny.phenos[first.in.family:last.in.family]) ; sorted <-sort(temp,decreasing=TRUE)
      phenos.1 <- as.matrix(all.phenos); colnames(phenos.1) <- "Vol"
      gp <- create.gpData(pheno=phenos.1, pedigree=ped); A.Rel.Mat  <- kin(gp,ret="add"); rel.mat <-data.frame(A.Rel.Mat); colnames(rel.mat) <- ped[,1]
      } else {
        temp <- (progeny.blups[first.in.family:last.in.family]) ; sorted <-sort(temp,decreasing=TRUE)}
      for (i in 1:2){BestOne <- which(temp==sorted[i]) ; selected <- BestOne + first.in.family - 1 ;Selections <- c(Selections, selected)}
      first.in.family <- last.in.family + 1 }} 
  
  if (sbpm) {
    if (ablup){
      c.ped <- cbind(ped[,1:3],y=all.phenos)
      c.ped <- as.data.frame.matrix(c.ped)
      colnames(c.ped) <- c("ID","SIRE","DAM","y")
      c.ped[,1] <- as.integer(c.ped[,1])
      c.ped[,2] <- as.numeric(c.ped[,2])
      c.ped[,3] <- as.numeric(c.ped[,3])
      c.ped[,4] <- as.numeric(c.ped[,4])
      c.ped <- data.frame(c.ped)
      
      sol1 <- blup(y ~ 1,ped=c.ped,alpha = 9)
      phenos.1 <- as.matrix(all.phenos); colnames(phenos.1) <- "Vol"
      gp <- create.gpData(pheno=phenos.1,pedigree=ped);
      ADD.Rel.Mat <- kin(gp,ret="add") ; rel.mat <- data.frame(ADD.Rel.Mat); colnames(rel.mat) <- ped[,1]
      #PBLUP <- gpMod(gp, model="BLUP", trait = "Vol", kin=ADD.Rel.Mat, markerEffects=F,predict=F)
      #  g <- match(names(progenyphenos$phenos),rownames(PBLUP$fit$predicted)) 
      #  progeny.blups <- PBLUP$fit$predicted[g] ; names(progeny.blups) <- names(progenyphenos$phenos) 
      g <- match(names(progenyphenos$phenos),rownames(sol1)) 
      progeny.blups <- sol1[g,1] ; names(progeny.blups) <- names(progenyphenos$phenos) 
    }  
    if (gblup){
      class(all.markers) <- "numeric"
      c.ped <- cbind(ped[,1:3],y=all.phenos)
      c.ped <- data.frame(c.ped)
      colnames(c.ped) <- c("ID","SIRE","DAM","y")
      c.ped[,1] <- as.integer(c.ped[,1])
      c.ped[,2] <- as.numeric(c.ped[,2])
      c.ped[,3] <- as.numeric(c.ped[,3])
      c.ped[,4] <- as.numeric(c.ped[,4])
      sol <- gblup(y ~ 1,data=c.ped[,c(1,4)],M=all.markers,lambda = 9)
      #test <- all.markers-1
      #A <- A.mat(test)
      #data <- data.frame(y=all.phenos,gid=as.numeric(rownames(all.markers)))
      #t <- proc.time()
      #ans <- kin.blup(data,geno="gid",pheno="y",K=A)
      
      phenos.1 <- as.matrix(all.phenos); colnames(phenos.1) <- "Vol"
      gp <- create.gpData(pheno=phenos.1, pedigree=ped)
      #G.Rel.Mat <- kin(gp,ret="realized"); A.Rel.Mat <- kin(gp,ret="add"); rel.mat <- data.frame(A.Rel.Mat); colnames(rel.mat) <- ped[,1]
      A.Rel.Mat <- kin(gp,ret="add"); rel.mat <- data.frame(A.Rel.Mat); colnames(rel.mat) <- ped[,1]
      #t <- proc.time()
      #GBLUP <- gpMod(gp, model="BLUP", trait = "Vol", kin=G.Rel.Mat, predict=T, markerEffects=F)
      #proc.time()-t
      #g <- match(names(progenyphenos$phenos),rownames(GBLUP$fit$predicted))
      #progeny.blups <- GBLUP$fit$predicted[g]; names(progeny.blups) <- names(progenyphenos$phenos)
      #progeny.blups <- ans$g[which(names(ans$g) %in% names(progenyphenos$phenos))]
      g <- match(names(progenyphenos$phenos),rownames(sol)) 
      progeny.blups <- sol[g,1] ; names(progeny.blups) <- names(progenyphenos$phenos) 
    }
    sorted.EBVs <- sort(progeny.blups, decreasing = T)
    for(i in 1:numSelections){
      selected <- which(progeny.blups==sorted.EBVs[i]); Selections <- c(Selections,selected)}}
  
  
  # Extract phenotypes of new selections
  Selection.phenos<- progeny.phenos[Selections]
  if (p){Selection.EBvs <- Selection.phenos} 
  if(gblup | ablup | hblup | assortivemating) {Selection.EBvs <- aprogeny.blups[Selections]} #change for a or g dependeing on what to take
  sorted.top192 <- sort(Selection.phenos,decreasing=T)
  all.markers <- rbind(parent.markers,prog.markers[Selections,])
  if(gen==1){
    if(SelfPar | reduced){  all.phenos <- c(past.phenos$phenos[as.numeric(names(pars))],Selection.phenos)
    } else {all.phenos <- c(past.phenos$phenos,Selection.phenos)}
  } else { all.phenos <- c(past.phenos$all.phenos,Selection.phenos)}
  ped <- data.frame(full.ped[which(full.ped[,1] %in% as.numeric(names(all.phenos))),])
  
  # Extract genotypes and parent ids of new selections
  new.parent.genos <- progenyinfo$genos.3d[,Selections,]
  numselections <- dim(new.parent.genos)[2]
  new.pars.genval <- prog.genetic.values[Selections]
  new.pars.genval.ifwithin.g <- NULL
  #new.pars.genval.ifwithin.g <- prog.genetic.values[if.other.Selections]
  select.ids <- as.numeric(names(new.pars.genval))-numparents
  select.ped.ids <- as.numeric(names(new.pars.genval))  
  if (selftest) {colnames(new.parent.genos) <- select.ped.ids} else {colnames(new.parent.genos) <- names(Selections)}
  
  # Calculate: 
  #       Inbreding level of progeny/selections
  #       Genetic Variance of progeny and selections (Bulmer Effect)
  pedigree.inbreeding <- calcInbreeding(selection.ped[,1:3])
  names(pedigree.inbreeding) <- selection.ped[,1]
  progeny.inbreeding <- pedigree.inbreeding[prog.pedigree[,1]]
  selections.inbreeding <- progeny.inbreeding[Selections]
  progeny.gen.var <- var(prog.genetic.values)
  bulmer.effect <- var(prog.genetic.values[Selections]) - var(prog.genetic.values)
  
  #Calculate the number of deletrious alleles for each selection
  result <- sapply(rep(1:length(Selections),1),function(x) {out <-length(which(new.parent.genos[mapinfo$QTLSNP.loci,,1][,x]=="c")); out2 <- length(which(new.parent.genos[mapinfo$QTLSNP.loci,,2][,x]=="c"))
  outer <- out+out2})
  result <- unlist(result)
  
  phenos.1 <- as.matrix(all.phenos[match(ped[,1],names(all.phenos))]); colnames(phenos.1) <- "Vol"
  pedd <- create.pedigree(ped[,1],ped[,2],ped[,3])
  gp <- create.gpData(pheno=phenos.1,pedigree=pedd);
  rel.mat <- data.frame(kin(gp,ret="add")) ; colnames(rel.mat) <- pedd[,1]
  
  extraction.info<-list(relmat=rel.mat, delt.alleles=result, selections=Selections, bulmer.effect=bulmer.effect, 
                        select.EBVs = Selection.EBvs,
                        selection.phenos=Selection.phenos,ped=ped, prog.inbred.level=progeny.inbreeding, select.inbred.level=selections.inbreeding,
                        genos.3d=new.parent.genos, num.parents=numselections,select.genval=new.pars.genval, fullped=full.ped,
                        if.g.select.genval=new.pars.genval.ifwithin.g,
                        par.ids=select.ids,select.ped.ids=select.ped.ids,all.markers=all.markers,all.phenos=all.phenos, cumulative.total=crossdesign.inuse$cumul.total)
  cat("The returned object is a list containing a matrix of phenotypic data with\n")
  cat("the specified heritability, a vector of unscaled true genetic values,\n")
  cat("to the same total variance as the phenotypic values, and a vector of\n" )
  cat("selected individuals, four per family, with the highest phenotype value.\n" )
  cat("Both phenotypes and true genetic values include values for parents first followed by progeny.\n")
  
  return(extraction.info)
  # # # # #   End of createPhenos() function # # # # # # # #
}

