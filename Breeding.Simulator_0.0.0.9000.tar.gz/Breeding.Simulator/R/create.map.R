#' Create Map
#'
#' This function allows you to create a genetic map
#' @param chromoszies heritabilty
#' @keywords extract genos from make crosses
#' @export
#' @examples
#' create.map()

#Create Map####
create.map <- function(haldane=Haldane,save=Save, 
                       #If things are known
                       knowchromosmesize=know.chromosome.size, chromosizes=chromo.sizes,
                       knowlociperchromo=know.loci.per.chromo, lociperchromo=loci.per.chromo,
                       knowSNPQTL=know.SNPQTL, knownSNPQTL=known.SNPQTL,
                       knowSNPQTLMAFs =know.SNPQTL.MAFs,knownSNPQTLMAFs = known.SNPQTL.MAFS,
                       knowrQTL=know.rQTL, knownrQTLloci=known.rQTL.loci,
                       knowrQTLMAFs=know.rQTL.MAFs,knownrQTLMAFs=known.rQTL.MAFs,
                       knowMarkerMAFs=know.Marker.MAFs,knownMarkerMAFs=known.Marker.MAFs,
                       #If things are unknown
                       num.markers=NumMarkers,totalQTL=TotalQTL,numSNPQTL=NumSNPQTL,seed=seed.set,
                       numchromos=num.chromos,maplength=map.length, totalloci=total.loci,
                       signifdigits=2,rep.num=Rep) {
  
  # Determine sizes of each chromosome##
  {
    #If known they are specified as input vector
    if(knowchromosmesize){chromosizes <- chromosizes
    avgchromo <- maplength/numchromos
    } else {
      #If unknown, size is based on the average chromo size multiplied by an upper/lower size range
      lowchromosizerange=0.25 
      highchromosizerange =.42
      avgchromo <- maplength/numchromos 
      if(seed){set.seed(32423)}  #If true, a seed is set so that chromosome sizes are the exact same every time
      chromosizes <- floor(runif(numchromos, min=(avgchromo - lowchromosizerange*avgchromo), max=(avgchromo + highchromosizerange*avgchromo)))
    }}
  
  # Determining the number of intervals that will be calculated and the number of loci per chromosome
  numintervals <- totalloci-1 #Specifying the # of intervals that will need to be calcuated
  if(knowlociperchromo){chromoloci <- lociperchromo} else {
    chromoloci <- rep(totalloci/numchromos,numchromos)} #Each chromosome will get an equal number of loci
  #Specify the last loci for each chromosome
  all.loci <- vector("list",12)
  for (i in 1:length(chromoloci)){
    if (i==1){all.loci[[1]] <- chromoloci[i] } else {
      all.loci[[i]] <- chromoloci[[i]] + all.loci[[i-1]]}}
  chromo.loci <- unlist(all.loci)
  
  ##Create Map and Recombination Frequencies###
  {
    # Creating empty vectors 
    list1<-vector("list", totalloci) # List "chr#" character set for all loci
    list2<-vector("list", totalloci) # List locus# for all chromosomes
    intervals<-rep(NA, totalloci)    # Holds interval distance from each locus to the previous one
    positions<- rep(NA, totalloci)   # Holds the positions of each loci on a chromosome in cM
    locusnames<-rep(NA,totalloci)    # Holds each locus name for all of the loci (chr1_locus#)
    recfreqs<-rep(NA, totalloci)     # Holds Recombination frequency for each of the loci
    
    # Define map function used to create recombination frequencies:
    if(haldane) {mapfun<-function(x){(1-(exp(-2*x)))/2 }} else {mapfun <- function(x){ ( (exp(2*x) - exp(-2*x))/(exp(2*x) + exp(-2*x)) )/2}}
    
    ## Start with chromosome 1 - note that "interval" is distance from locus n to n-1, not n+1
    for(k in 1:numchromos){
      # For each chromosome list 1 will contain the number of loci for that chromsome
      list1[(1+sum(chromoloci[1:k-1])):sum(chromoloci[1:k])]<-c(1:chromoloci[k])
      # list2 will hold the chr# that can later be pasted with list1 to make locus names
      list2[(1+sum(chromoloci[1:k-1])):sum(chromoloci[1:k])]<-rep(paste("chr",k,sep=""))
      
      # Intervals are initally in cM but divided by 100 to be Morgans.  This is done so that it can be input to haldane function 
      # which uses Morgans to calculate Recfreqs
      intervals[(1+sum(chromoloci[1:k-1])):sum(chromoloci[1:k])]<-c((round(runif((chromoloci[k]-1),min=(0.2*chromosizes[k]/chromoloci[k]), 
                                                                                 max=(1.74*chromosizes[k]/chromoloci[k])),signifdigits))/100,5)
      # The last locus interval is determined by the mean interval of all previous loci
      intervals[sum(chromoloci[1:k])]<- mean(intervals[(1+sum(chromoloci[1:k-1])):(sum(chromoloci[1:k]-1))])
      
      #Recfreqs for each of the loci are determined by using the interval distance (for each locus) in Morgans and the haldane mapping function:
      #r=(1/2)*(1-e^(2*M))
      recfreqs[(1+sum(chromoloci[1:k-1])):sum(chromoloci[1:k])] <- mapfun(intervals[(1+sum(chromoloci[1:k-1])):sum(chromoloci[1:k])])
      
      #Since intervals are in Morgans, we multiply by 100 to turn it back into cM for positions (cM is unit for chromosome lengths)
      positions[(1+sum(chromoloci[1:k-1])):sum(chromoloci[1:k])]<- round(100*cumsum(intervals[(1+sum(chromoloci[1:k-1])):sum(chromoloci[1:k])]),digits=8)
    }
    
    ## paste together locus names from list2 and list1
    locusnames<- paste(list2,list1,sep="_")
    
    #Create map that has locusnames, distance between loci, empty vector of types (SNPQTL,rQTL, or Marker), MAFs, position on chromosome, & rec freqs
    map<-data.frame(chr=unlist(list2),loci=locusnames, dist= as.numeric(intervals),types= rep(NA,totalloci), MAF=rep(NA,totalloci), pos=as.numeric(positions),recfreqs=as.numeric(recfreqs))
  }
  
  #Now sample from the map to specify SNPQTL & rQTL, the remainder are potential markers that can be used
  all.loci <- 1:totalloci  # vector that contains 1 through the number of all loci
  
  if(seed) {set.seed(132233523)}     # If set seed so that the same set of minor allele frequencies are drawn from beta distribution
  if(knowMarkerMAFs){
    map$MAF[-c(SNPQTL,rQTL)] <- knownMarkerMAFs
    map$types[-c(SNPQTL,rQTL)] <- "m" 
  } else {
    #Sample 10 markers for each chromosome uniformly distributed
    smp <- num.markers/12
    last.pos.chrs <-  sapply(1:12,function(x){round(map$pos[chromo.loci[x]],0)})
    Markers <- vector()
    for(i in 1:length(chromoloci)){
      equal.dist.per.chr <- last.pos.chrs[i]/smp
      map.posit <- map$pos[(chromo.loci[i]-chromo.loci[1] +1):(chromo.loci[i])]
      Marker <- sapply(1:smp,function(x){
        the.pos <- equal.dist.per.chr*x
        which.min(abs(round(map.posit - the.pos,1)))})
      if(i > 1){Marker <- Marker + chromo.loci[i-1]}
      Markers <- c(Markers,Marker)}
    
    map$types[Markers] <- "m"    # Specify in map data frame that all loci which are not qtl or snpqtl are markers
    MAFs <- sample(rbeta(200000,.4,.4),totalloci,replace=F)
    MAFs[which(MAFs > .5)] <- 1- MAFs[which(MAFs > .5)]
    #MAFs <- sample(runif(totalloci,.2,.49),size = totalloci)
    map$MAF <- sample(MAFs,length(map$MAF),replace=F) # Assign minor allele frequencies to markers and qtl
  }  
  
  
  if(seed){set.seed(123135)} # If seed true, it can be set so that same SNPQTL positions are samples each time from all.loci
  if(knowSNPQTL){SNPQTL <- knownSNPQTLloci} else {  
    SNPQTL <- sample(all.loci[-Markers],numSNPQTL,replace=FALSE)}
  
  if(seed){set.seed(23423)}  # If seed true, set seed so that snp qtl MAF are reproducible
  if(knowSNPQTLMAFs){SNPQTLMAFs <- knownSNPQTLMAFS} else {
    SNPQTLMAFs <- runif(numSNPQTL,min=.01,max=.02)}
  map$types[SNPQTL] <- "snpqtl"   # Specify in the map data frame that these loci are snpqtl
  map$MAF[SNPQTL] <- SNPQTLMAFs   # Assign these loci the specificed minor allele frequencies generated by user
  
  
  numQTL <- totalQTL - numSNPQTL  # vector that contains the number of QTL which are not under dominance and have addtive effects
  if(seed) {set.seed(234253)}       #If seed is set so that the same loci are sampled to be rQTLs
  if(knowrQTL){rQTL <- knownrQTLloci} else {
    rQTL <- sample(all.loci[-c(SNPQTL,Markers)],numQTL,replace=F)}
  map$types[rQTL] <- "qtl"        # Specify in the map data frame that these loci are qtl
  
  if(seed) {set.seed(1323523)}     # If set seed so that the same set of minor allele frequencies are drawn from beta distribution
  if(knowrQTLMAFs){MAFs <- knownrQTLMAFs
  map$MAF[rQTL] <- MAFs} else {
    MAFs <- sample(rbeta(200000,.4,.4),totalloci,replace=F)
    MAFs[which(MAFs > .5)] <- 1- MAFs[which(MAFs > .5)]
    map$MAF[rQTL] <- sample(MAFs,length(map$MAF[rQTL]),replace=F)
  }
  
  
  
  
  #Now save map output:
  datevalue <- date()
  datevector <- unlist(strsplit(datevalue,"\\s"))
  timevector <- unlist(strsplit(datevector[4],":"))
  newtime <- paste(timevector[1],timevector[2],sep="h")
  newdate <- paste(datevector[3],datevector[2],datevector[5],sep="")
  namestem <- paste(newdate,newtime,sep="_")
  
  if(save) {
    mapname<-paste(rep.num,namestem,"_map.txt")
    write.table(map,file=mapname, quote=F, row.names=F, col.names=T, sep="\t")
  }
  mapinfo<-list(genetic.map=map, total.loci.num=totalloci,total.QTL.num=totalQTL, total.SNPQTL.num=numSNPQTL,
                QTLSNP.loci=sort(SNPQTL),date.time=namestem, rQTL.loci=sort(rQTL), available.Markers=Markers,last.locus.per.chrom=chromo.loci)
  cat("The returned object is a list containing:\n")
  cat("a matrix of 5 columns with locus names, intervals, types (marker, snp, or qtl), MAFs, and recombination fractions;\n")
  cat("a set of scalars with the numbers of total loci, total QTL, SNPs that are also QTL, total SNPs, and map intervals,\n")
  cat("vectors identifying which loci are SNPs, which are SNP-QTL, and which are 'invisible' QTL,\n")
  cat("and the namestem prefix used in saving text output files.\n")
  return(mapinfo)
  # End of function #
}
