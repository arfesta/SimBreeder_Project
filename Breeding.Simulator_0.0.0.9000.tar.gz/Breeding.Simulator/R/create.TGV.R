#' Create TGV
#'
#' This function allows you to create total genetic values
#' @param data1 parents
#' @keywords extract genos from make crosses
#' @export
#' @examples
#' create.TGV()

####Create  TGV Genetic Value####
create.TGV <- function(data1=parents, mapinfo=map, crossdesign=cross.design, gen=gen,
                       majorallelevalue=Major.allele.value,minorallelevalue=Minor.allele.value,
                       usesnpeffect=useSNPeffects,snpeffect=SNPeffects,
                       Dom.coeff=dom.coeff, num.markers=NumMarkers,
                       save=Save, rep.num=Rep, prefix=prefix){
  
  dom.coeff <- Dom.coeff         # Dominance coeffecient that is set by user
  locusnames <- mapinfo$genetic.map$loci # The locus names pulled from the mab object
  QTLSNPs <- mapinfo$QTLSNP.loci     # vector of the loci which are snpqtl
  QTLSNPnum <- data1$genos.3d[QTLSNPs,,] # genotypes of both alleles pulled from the current generation
  markers <- map$available.Markers# a list of all the markers pulled from map object
  #markers <- rownames(markers[which(markers$MAF <.2),])
  #set.seed(45234235) # seed is set making the loci which are selected as markers the same every time
  markers.select <- sort(sample(markers,num.markers,replace=F),decreasing=F)
  num.markers <- length(markers.select) # length of markers that were selected
  marker.select.genos <- data1$genos.3d[markers.select,,] # genotypes of the markers pulled from the current generation
  map.markers <- mapinfo$genetic.map[markers.select,c(1,6)]
  numQTL <- length(mapinfo$rQTL.loci) # the number of additive qtl
  if (gen==0){
    parIDs <- data1$parent.IDs
  } else {
    parIDs <- crossdesign$parent.IDs} # the parent ids pulled from the current generation
  
  
  # Assign each snpqtl a value
  A <- majorallelevalue    # Major allele is assigned 
  a <- minorallelevalue  # Minor allele is assigned
  
  # Create 2 matrices: One to hold snpqtl values for all parents and the other to hold marker marker values for blup analysis
  numSNPQTL <- mapinfo$total.SNPQTL.num # the number of loci which are snpqtl
  numparents <- length(parIDs) # the number of parents
  QTLSNPvalues <-matrix(NA,nrow=numSNPQTL,ncol=numparents) # matrix to hold snpqtl values
  marker.values <- matrix(NA,nrow=num.markers,ncol=numparents) # matrix to hold marker values
  Capital.genotypes <- vector()
  Lowercase.genotypes <- vector()
  for (i in 1:26){
    Capital.genotypes <- c(Capital.genotypes,paste(LETTERS[i],LETTERS, sep=""))
    Lowercase.genotypes <-  c(Lowercase.genotypes,paste(letters[i],letters, sep=""))
  }
  
  
  for (i in 1:length(parIDs)){
    QTLSNPaa <- which(QTLSNPnum[,i,1]=="a" & QTLSNPnum[,i,2]=="a")
    QTLSNPcc <- which(QTLSNPnum[,i,1]=="c" & QTLSNPnum[,i,2]=="c")
    QTLSNPac <- which(QTLSNPnum[,i,1]=="a" & QTLSNPnum[,i,2]=="c")
    QTLSNPca <- which(QTLSNPnum[,i,1]=="c"  & QTLSNPnum[,i,2]=="a")
    if (dom.coeff==0){
      QTLSNPvalues[QTLSNPaa,i] <- A*2
      QTLSNPvalues[QTLSNPcc,i] <- a*2
      QTLSNPvalues[QTLSNPac,i] <- (A+a+dom.coeff)
      QTLSNPvalues[QTLSNPca,i] <- (A+a+dom.coeff) } else {
        QTLSNPvalues[QTLSNPaa,i] <- A
        if(usesnpeffect){
          QTLSNPvalues[QTLSNPcc,i] <- snpeffect[a]
        } else{
          QTLSNPvalues[QTLSNPcc,i] <- a}
        QTLSNPvalues[QTLSNPac,i] <- (A*dom.coeff)
        QTLSNPvalues[QTLSNPca,i] <- (A*dom.coeff)
      }
    
    markers.aa <- which(marker.select.genos[,i,1] %in% Capital.genotypes & marker.select.genos[,i,2] %in% Capital.genotypes)
    #markers.aa <- which(marker.select.genos[,i,1]=="D" & marker.select.genos[,i,2]=="D")
    #markers.cc <- which(marker.select.genos[,i,1]=="d" & marker.select.genos[,i,2]=="d")
    markers.cc <- which(marker.select.genos[,i,1] %in% Lowercase.genotypes & marker.select.genos[,i,2] %in% Lowercase.genotypes)
    #markers.ac <- which(marker.select.genos[,i,1]=="D" & marker.select.genos[,i,2]=="d")
    markers.ac <-which(marker.select.genos[,i,1] %in% Capital.genotypes & marker.select.genos[,i,2] %in% Lowercase.genotypes)
    #markers.ca <- which(marker.select.genos[,i,1]=="d"  & marker.select.genos[,i,2]=="D")
    markers.ca <- which(marker.select.genos[,i,1] %in% Lowercase.genotypes & marker.select.genos[,i,2] %in% Capital.genotypes)
    
    marker.values[markers.aa,i] <- "0"
    marker.values[markers.cc,i] <- "2"
    marker.values[markers.ac,i] <- "1"
    marker.values[markers.ca,i] <- "1"
  }
  marker.values <- t(marker.values)
  colnames(marker.values) <- markers.select
  rownames(marker.values) <- parIDs
  
  # Convert the 'invisible' rQTL genotypes to numeric matrices, merge the alleles to paired values also
  parQTLallele1 <- matrix(as.integer(data1$genos.3d[mapinfo$rQTL,,1]),nrow=numQTL,ncol=numparents)
  colnames(parQTLallele1) <- c(parIDs)
  parQTLallele2 <- matrix(as.integer(data1$genos.3d[mapinfo$rQTL,,2]),nrow=numQTL,ncol=numparents)
  colnames(parQTLallele2) <- c(parIDs)
  QTLvalues     <- matrix(paste(parQTLallele1,parQTLallele2,sep=","),nrow=numQTL,ncol=numparents)
  dimnames(QTLvalues)<-list(locusnames[mapinfo$rQTL],parIDs)
  
  # Genetic values of progeny
  geneticvals <- colSums(QTLSNPvalues) + colSums(parQTLallele1) + colSums(parQTLallele2)
  
  if(save) {
    pedfilename=paste(rep.num,prefix,".txt", sep="")
    write.table(geneticvals,pedfilename, quote = F, row.names = F, col.names = T, sep="\t")
  }
  
  TGV <- list(genetic.values=geneticvals, SNP.value.matrix=QTLSNPvalues, markers.matrix=marker.values, marker.loci=markers.select, marker.map=map.markers)
  return(TGV)
}
