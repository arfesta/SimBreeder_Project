#' Create TGV2 without extracting genos
#'
#' This function allows you to create total genetic values
#' @param data1 parents
#' @keywords extract genos from make crosses
#' @export
#' @examples
#' create.TGV2()

####Create TGV2####
create.TGV2 <- function(data1=parents, mapinfo=map, crossdesign=cross.design, gen=gen,
                        majorallelevalue=Major.allele.value,minorallelevalue=Minor.allele.value,
                        usesnpeffect=useSNPeffects,snpeffect=SNPeffects,
                        Dom.coeff=dom.coeff, num.markers=NumMarkers,
                        save=Save, rep.num=Rep, prefix=prefix){
  
  dom.coeff <- Dom.coeff         # Dominance coeffecient that is set by user
  QTLSNPs <- mapinfo$QTLSNP.loci     # vector of the loci which are snpqtl
  QTLSNPnum <- data1$genos.3d[QTLSNPs,,] # genotypes of both alleles pulled from the current generation
  markers <- mapinfo$available.Markers# a list of all the markers pulled from map object
  markers.select <- sort(sample(markers,num.markers,replace=F),decreasing=F)
  num.markers <- length(markers.select) # length of markers that were selected
  marker.select.genos <- data1$genos.3d[markers.select,,] # genotypes of the markers pulled from the current generation
  map.markers <- mapinfo$genetic.map[markers.select,c(1,6)]
  numQTL <- length(mapinfo$rQTL.loci) # the number of additive qtl
  
  parIDs <- crossdesign$parent.IDs
  length.prog <- length(parIDs)
  
  
  numSNPQTL <- mapinfo$total.SNPQTL.num # the number of loci which are snpqtl
  numparents <- length(parIDs) # the number of parents
  #QTLSNPvalues <-matrix(NA,nrow=numSNPQTL,ncol=numparents) # matrix to hold snpqtl values
  marker.values <- matrix(NA,nrow=num.markers,ncol=numparents) # matrix to hold marker values
  Capital.genotypes <- vector()
  Lowercase.genotypes <- vector()
  for (i in 1:26){
    Capital.genotypes <- c(Capital.genotypes,paste(LETTERS[i],LETTERS, sep=""))
    Lowercase.genotypes <-  c(Lowercase.genotypes,paste(letters[i],letters, sep=""))
  }
  
  # Assign each snpqtl a value
  A <- majorallelevalue    # Major allele is assigned 
  a <- minorallelevalue  # Minor allele is assigned
  
  QTLSNPaa <- sapply(1:length.prog,function(x){
    A*length(which(QTLSNPnum[,x,1]=="a" & QTLSNPnum[,x,2]=="a"))},simplify = T)
  QTLSNPcc <- sapply(1:length.prog,function(x){
    a*length(which(QTLSNPnum[,x,1]=="c" & QTLSNPnum[,x,2]=="c"))},simplify = T)
  QTLSNPac <- sapply(1:length.prog,function(x){
    (A * dom.coeff) * length(which(QTLSNPnum[,x,1]=="a" & QTLSNPnum[,x,2]=="c"))},simplify = T)
  QTLSNPca <- sapply(1:length.prog,function(x){
    (A * dom.coeff) * length(which(QTLSNPnum[,x,1]=="c" & QTLSNPnum[,x,2]=="a"))},simplify = T)
  QTLSNPvalues <- QTLSNPaa+QTLSNPcc+QTLSNPac+QTLSNPca
  
  
  markers.aa <-   sapply(1:length.prog,function(x){
    which(marker.select.genos[,x,1] %in% Capital.genotypes & marker.select.genos[,x,2] %in% Capital.genotypes)},simplify = T)
  markers.cc <-   sapply(1:length.prog,function(x){
    which(marker.select.genos[,x,1] %in% Lowercase.genotypes & marker.select.genos[,x,2] %in% Lowercase.genotypes)},simplify = T)
  markers.ac <-   sapply(1:length.prog,function(x){
    which(marker.select.genos[,x,1] %in% Capital.genotypes & marker.select.genos[,x,2] %in% Lowercase.genotypes)},simplify = T)
  markers.ca <-   sapply(1:length.prog,function(x){
    which(marker.select.genos[,x,1] %in% Lowercase.genotypes & marker.select.genos[,x,2] %in% Capital.genotypes)},simplify = T)
  marker.values <- matrix(NA,nrow=num.markers,ncol=length.prog) # matrix to hold marker values
  
  for(i in 1:length.prog){
    marker.values[markers.aa[[i]],i] <- "0"
    marker.values[markers.cc[[i]],i] <- "2"
    marker.values[markers.ac[[i]],i] <- "1"
    marker.values[markers.ca[[i]],i] <- "1"}
  
  marker.values <- t(marker.values)
  colnames(marker.values) <- markers.select
  rownames(marker.values) <- parIDs
  
  geneticvals <- QTLSNPvalues + colSums( matrix(as.integer(data1$genos.3d[mapinfo$rQTL,,1]),nrow=numQTL,ncol=length.prog)) + colSums(matrix(as.integer(data1$genos.3d[mapinfo$rQTL,,2]),nrow=numQTL,ncol=length.prog))
  names(geneticvals) <- parIDs
  
  TGV <- list(genetic.values=geneticvals, SNP.value.matrix=QTLSNPvalues, markers.matrix=marker.values, marker.loci=markers.select, marker.map=map.markers)
  return(TGV)}
